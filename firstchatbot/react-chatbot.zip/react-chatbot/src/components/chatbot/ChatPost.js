import React, { Component } from 'react';
import axios from 'axios';


class ChatPost extends Component {
  constructor(props) {
    super(props);
    const { steps } = this.props;
    const { submit, firstname, lastname, email, mobile } = steps;

    this.state =  { submit, firstname, lastname, email, mobile }; 
  }


  componentDidMount() {
    const userObject = {
      submit:this.state.submit.value,
      first_name:this.state.firstname.value,
      last_name:this.state.lastname.value,
      email:this.state.email.value,
      mobile:this.state.mobile.value,
    };
    axios.post(`/api/submitchat`, userObject)
    .then(res => {
      console.log(res.status)
    }).catch(function(error) {
      console.log(error);
    });
  }


  render() {
    return (
      <div class="thank-you-data">Thank you! Your data was submitted successfully!
          <table>
              <tr><td>Full Name: </td><td>{this.state.firstname.value} {this.state.lastname.value}</td></tr>
              <tr><td>Email: </td><td>{this.state.email.value}</td></tr>
              <tr><td>Mobile Number: </td><td>{this.state.mobile.value}</td></tr>
          </table>
    </div>
      );
    }
  };


  export default ChatPost;