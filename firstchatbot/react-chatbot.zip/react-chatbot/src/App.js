// import logo from './logo.svg';
import './App.css';
import ChatMessageForm from "./components/chatbot/ChatMessageForm";


function App() {
  return (
    <div className="App">
      Hello, How may I help you?
      <ChatMessageForm />
    </div>
  );
}

export default App;
